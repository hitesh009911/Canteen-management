from django.shortcuts import render, HttpResponse, HttpResponseRedirect,  get_object_or_404, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from canteen.models import FoodItem
from .models import Cart, Orders, OrderItems, Feedback, Recommendation, Profile
from .forms import LoginRegisterForm, RecommendationForm, ProfileForm
import random
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Count, Sum
from order.models import Food, Recommendation
from django.views.decorators.csrf import csrf_exempt
from .forms import FoodItemForm
from .models import Profile
from django.db.models.signals import post_save
from django.dispatch import receiver

# Create your views here.
def index(request):
    food = FoodItem.objects.all()
    name_quantity_of_all_food = []
    if(request.user.is_authenticated):
        cartitems = Cart.objects.filter(username=request.user)
        for f in food:
            find = False
            name_quantity_combo = []
            for item in cartitems:
                if(f.name == item.food.name):
                    name_quantity_combo.append(f.name)
                    name_quantity_combo.append(item.quantity)
                    find = True
                    break
            if(not find):
                name_quantity_combo.append(f.name)
                name_quantity_combo.append('0')
            name_quantity_of_all_food.append(name_quantity_combo)
    return render(request, 'order/index.html', {'food':food, 'cartitems':name_quantity_of_all_food})

def register(request):
    if(request.method == 'GET'):
        form = LoginRegisterForm()
        return render(request, 'order/register.html', {'form':form})
    elif(request.method == 'POST'):
        form = LoginRegisterForm(request.POST)
        un = request.POST.get('username')
        pw = request.POST.get('password')
        if(User.objects.filter(username=un).exists()):
            messages.warning(request, 'User Already Exists, try other unique username')
            return HttpResponseRedirect('/register/')
        else:
            if(form.is_valid()):
                un = form.cleaned_data['username']
                pw = form.cleaned_data['password']
                new_user = User(username=un)
                new_user.set_password(pw)
                new_user.save()
                messages.success(request, 'Account Created Successfully, You can Login Now')
                return HttpResponseRedirect('/login/')

def user_login(request):
    if(request.method == 'GET'):
        form = LoginRegisterForm()
        return render(request, 'order/login.html', {'form':form})
    elif(request.method == 'POST'):
        form = LoginRegisterForm(request.POST)
        un = request.POST.get('username')
        pw = request.POST.get('password')
        if(not User.objects.filter(username=un).exists()):
            messages.warning(request, 'User Does Not Exist or Wrong Password, Try Again')
            return HttpResponseRedirect('/login/')
        else:
            auth_user = authenticate(username=un, password=pw)
            if(auth_user):
                login(request, auth_user)
                return HttpResponseRedirect('/')
            else:
                messages.warning(request, 'User Does Not Exist or Wrong Password, Try Again')
                return HttpResponseRedirect('/login/')

@login_required(login_url='/login/')
def update_cart(request, f_id):
    food = FoodItem.objects.get(id=f_id)

    # Check if the item is already in the user's cart
    cart_item, created = Cart.objects.get_or_create(username=request.user, food=food)

    if not created:
        # If the item already exists, handle quantity updates based on request parameters
        action = request.GET.get('name')
        if action == 'increase_cart':
            cart_item.quantity += 1
        elif action == 'decrease_cart' and cart_item.quantity > 1:
            cart_item.quantity -= 1
        elif action == 'delete_cart_item':
            cart_item.delete()
            return HttpResponseRedirect('/cart/')

        cart_item.save()  # Save the updated item back to the cart

    # Redirect to the appropriate page after the update
    if 'cart' in request.META['HTTP_REFERER']:
        return HttpResponseRedirect('/cart/')
    else:
        return HttpResponseRedirect('/')

@login_required(login_url='/login/')
def cart(request):
    cartitems = Cart.objects.filter(username=request.user)
    total_amount = 0

    # Calculate the total amount
    if cartitems:
        for item in cartitems:
            sub_total = item.food.price * item.quantity
            total_amount += sub_total

    return render(request, 'order/cart.html', {'cartitems': cartitems, 'total_amount': total_amount})

@login_required(login_url='/login/')
def checkout(request):
    if(request.method == 'POST'):
        if(request.POST.get('paymode') == 'Cash'):
            tn_id = 'CASH' + str(random.randint(111111111111111,999999999999999))
            payment_mode = "Cash"
            payment_gateway = "Cash"
        elif(request.POST.get('paymode') == 'Online' and request.POST.get('paygate') == "Paypal"):
            tn_id = request.POST.get('tn_id')
            payment_mode = "Online"
            payment_gateway = "Paypal"
        else:
            return HttpResponse('<H1>Invalid Request</H1>')
        cartitems = Cart.objects.filter(username=request.user)
        total_amount = 0
        new_order = Orders(username=request.user, total_amount=total_amount, payment_mode=payment_mode, transaction_id=tn_id, payment_gateway=payment_gateway)
        new_order.save()
        if(cartitems):
            for item in cartitems:
                OrderItems(username=request.user, order=new_order, name=item.food.name, price=item.food.price, quantity=item.quantity, item_total=item.food.price * item.quantity).save()
                sub_total = item.food.price * item.quantity
                total_amount += sub_total
            Orders.objects.filter(id=new_order.id).update(total_amount=total_amount)
        cartitems.delete()
        return HttpResponseRedirect('/myorders/')
    else:
        return HttpResponse('<H1>Invalid Request</H1>')

@login_required(login_url='/login/')
def my_orders(request):
    orders = Orders.objects.filter(username=request.user).order_by("-order_datetime", "id")
    order_items = OrderItems.objects.filter(username=request.user)
    return render(request, 'order/myorders.html', {'orders': orders,'order_items': order_items})

def user_logout(request):
    logout(request)
    messages.success(request, 'Logout Successfully')
    return HttpResponseRedirect('/')

def get_food_menu(request):
    try:
        food_items = FoodItem.objects.all()
        menu_data = [{'id': item.id, 'name': item.name, 'price': item.price} for item in food_items]
        return JsonResponse(menu_data, safe=False)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required(login_url='/login/')
def check_login(request):
    return JsonResponse({'loggedIn': True})

# If the user is not logged in, you can return the following response
def check_login_not_logged_in(request):
    return JsonResponse({'loggedIn': False})

def payment(request):
    return render(request, 'order/payment.html')

def admin_dashboard(request):
    # Generate mock data for food items
    food_items = Food.objects.all()

    # Simulate sales and revenue
    food_names = []
    sales_values = []
    predictive_insights = []

    for food in food_items:
        sales = random.randint(50, 500)  # Random sales value
        revenue = sales * random.randint(20, 100)  # Random price per item
        food_names.append(food.name)
        sales_values.append(revenue)

        # Predictive analysis (mock data)
        predicted_sales = sales + random.randint(10, 50)
        current_stock = random.randint(10, 50)
        recommended_stock = predicted_sales + 10

        predictive_insights.append({
            "food_item__name": food.name,
            "predicted_sales": predicted_sales,
            "current_stock": current_stock,
            "recommended_stock": recommended_stock,
        })

    # Mock data for key metrics
    total_orders = random.randint(500, 1000)
    total_sales = sum(sales_values)  # Sum of sales values for total sales
    total_users = random.randint(100, 200)

    context = {
        "food_names": food_names,
        "sales_values": sales_values,
        "predictive_insights": predictive_insights,
        "total_orders": total_orders,
        "total_sales": total_sales,  # Make sure this is being passed
        "total_users": total_users,
    }
    return render(request, 'order/admin_dashboard.html', context)

@csrf_exempt
def toggle_sold_out(request, item_id):
    if not request.user.is_staff:
        return JsonResponse({'success': False, 'error': 'Unauthorized'}, status=403)

    item = get_object_or_404(FoodItem, id=item_id)
    item.sold_out = not item.sold_out  # Toggle the status
    item.save()

    return JsonResponse({'success': True, 'sold_out': item.sold_out})

@login_required
def toggle_sold_out(request, item_id):
    if not request.user.is_staff:
        return redirect('menu')  # Non-admins can't toggle status

    item = get_object_or_404(FoodItem, id=item_id)
    item.sold_out = not item.sold_out  # Toggle the status
    item.save()
    return redirect('order/menu.html')  # Redirect back to the menu

def menu(request):
    # Fetch all food items from the database
    food_items = FoodItem.objects.all()
    context = {'food_items': food_items}
    return render(request, 'order/menu.html', context)

def recent_purchases(request):
    # Fetch the 5 most recent purchases

    order_items = OrderItems.objects.select_related('order').all()

    return render(request, 'order/recent_purchase.html', {'order_items': order_items})

def feedback_list(request):
    feedbacks = Feedback.objects.select_related('user').order_by('-created_at')

    # Ensure that rating is always an integer and not None
    for feedback in feedbacks:
        if feedback.rating is None:
            feedback.rating = 0  # Set default rating if None

        # Convert the rating into a list of 1s (filled stars) and 0s (empty stars)
        feedback.stars = [1] * feedback.rating + [0] * (5 - feedback.rating)
    return render(request, 'order/feedback.html', {'feedbacks': feedbacks})

def my_orders(request):
    orders = Orders.objects.filter(username=request.user)
    orders = Orders.objects.filter(username=request.user).order_by("-order_datetime", "id")
    order_items = OrderItems.objects.filter(username=request.user)
    return render(request, 'order/myorders.html', {'orders': orders, 'order_items': order_items})

@login_required
def submit_feedback(request):
    if request.method == 'POST':
        order_id = request.POST.get('order_id')
        feedback_text = request.POST.get('feedback')
        rating = request.POST.get('rating')

        if order_id and feedback_text and rating:
            # Get the order instance
            order = Orders.objects.filter(id=order_id, username=request.user).first()
            if order:
                Feedback.objects.create(
                    user=request.user,
                    feedback=feedback_text,
                )
                messages.success(request, "Thank you for your feedback!")
            else:
                messages.error(request, "Invalid order.")
        else:
            messages.error(request, "All fields are required.")

    return redirect('my_orders')

def manage_recommendations(request):
    if request.method == 'POST':
        form = RecommendationForm(request.POST)
        if form.is_valid():
            # Create the recommendation and set the 'created_by' field to the current user
            recommendation = form.save(commit=False)
            recommendation.created_by = request.user  # This sets the currently logged-in user
            recommendation.save()
            return redirect('manage_recommendations')  # Redirect to a success page after saving
    else:
        form = RecommendationForm()

    recommendations = Recommendation.objects.all()
    return render(request, 'order/manage_recommendations.html', {'form': form, 'recommendations': recommendations})


def delete_recommendation(request, recommendation_id):
    # Fetch the recommendation object
    recommendation = get_object_or_404(Recommendation, id=recommendation_id)

    # Delete the recommendation
    recommendation.delete()

    # Display a success message
    messages.success(request, "Recommendation deleted successfully.")

    # Redirect to the page where recommendations are listed (for example, the same page)
    return redirect('manage_recommendations')
@login_required
def recommendations_page(request):
    recommendations = Recommendation.objects.all()
    return render(request, 'order/recommendations.html', {'recommendations': recommendations})

def manage_food_items(request):
    food_items = FoodItem.objects.all()

    if request.method == "POST":
        item_id = request.POST.get("food_item_id")
        food_item = get_object_or_404(FoodItem, id=item_id)
        food_item.sold_out = not food_item.sold_out
        food_item.save()
        return redirect("manage_food_items")  # Replace with the appropriate URL name for this view
    context = {
        "food_items": food_items,
    }
    return render(request, "order/menu.html", {"food_items": food_items})

def toggle_sold_out(request, item_id):
    food_item = get_object_or_404(FoodItem, id=item_id)
    food_item.sold_out = not food_item.sold_out  # Toggle the sold_out status
    food_item.save()
    return redirect("manage_food_items")

def add_food_item(request):
    if request.method == 'POST':
        form = FoodItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('manage-food-items')  # Redirect to the food items list
    else:
        form = FoodItemForm()
    return render(request, 'order/add.html', {'form': form})

def delete_food_item(request, food_item_id):
    food_item = get_object_or_404(FoodItem, id=food_item_id)
    food_item.delete()  # Delete the food item
    return redirect('manage-food-items')

def update_food_item(request, food_item_id):
    food_item = get_object_or_404(FoodItem, id=food_item_id)

    if request.method == "POST":
        form = FoodItemForm(request.POST, request.FILES, instance=food_item)  # Bind form to the existing food item
        if form.is_valid():
            form.save()  # Save the updated food item
            return redirect('manage-food-items')  # Redirect to manage page after updating
    else:
        form = FoodItemForm(instance=food_item)  # Pre-fill the form with current food item data

    context = {
        'form': form,
        'food_item': food_item,
    }
    return render(request, 'order/update.html', context)


def manage_orders(request):
    orders = Orders.objects.all().order_by("-order_datetime")

    if request.method == "POST":
        order_id = request.POST.get("order_id")
        action = request.POST.get("action")
        order = get_object_or_404(Orders, id=order_id)

        if action == "accept":
            order.status = "Accepted"
        elif action == "cooking":
            order.status = "Cooking"
        elif action == "ready":
            order.status = "Ready for Pickup"
        elif action == "finish":
            order.status = "Completed"
            order.items.all().delete()  # Use related_name 'items'
        order.save()

        messages.success(request, f"Order #{order.id} updated to {order.status}.")
        return redirect("manage_orders")

    context = {"orders": orders}
    return render(request, "order/manage_order.html", context)

def user_orders(request):
    user_orders = Orders.objects.filter(user=request.user).order_by("-created_at")
    context = {"orders": user_orders}
    return render(request, "order/orders.html", context)


@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, created, **kwargs):
    if created:
        # Create a profile for the newly created user
        Profile.objects.create(user=instance)
    else:
        # Ensure the profile exists before saving
        try:
            instance.profile.save()
        except Profile.DoesNotExist:
            # If profile does not exist, create it
            Profile.objects.create(user=instance)


def user_profile_view(request):
    if not request.user.is_authenticated:
        return redirect('login')  # Redirect to login if user is not authenticated

    profile, created = Profile.objects.get_or_create(user=request.user)

    # Optionally, if created is True, you can show a message or handle it differently
    return render(request, 'order/profile_view.html', {'profile': profile})


@login_required
def update_profile(request):
    """View to update the user's profile"""
    # Fetch the user's profile
    profile = Profile.objects.get(user=request.user)

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('user_profile_view')  # Redirect to profile page after saving

    else:
        form = ProfileForm(instance=profile)  # Prefill form with current profile data

    return render(request, 'order/profile_update.html', {'form': form})


def get_sales_data(request, timeframe):
    # Example of fetching different data based on timeframe (daily, weekly, monthly)
    if timeframe == 'daily':
        # Fetch daily sales data (just an example)
        sales_data = {
            'masala_dosa': {'sales': 50, 'stock': 100},
            'idli': {'sales': 30, 'stock': 80},
            'pongal': {'sales': 20, 'stock': 60},
        }
    elif timeframe == 'weekly':
        # Fetch weekly sales data
        sales_data = {
            'masala_dosa': {'sales': 350, 'stock': 700},
            'idli': {'sales': 210, 'stock': 560},
            'pongal': {'sales': 140, 'stock': 420},
        }
    elif timeframe == 'monthly':
        # Fetch monthly sales data
        sales_data = {
            'masala_dosa': {'sales': 1500, 'stock': 3000},
            'idli': {'sales': 900, 'stock': 2400},
            'pongal': {'sales': 600, 'stock': 1800},
        }

    return JsonResponse(sales_data)