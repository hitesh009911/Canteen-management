from django.contrib.auth.models import User
from django import forms
from .models import Recommendation, Profile
from django.contrib import admin
from canteen.models import FoodItem


class LoginRegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model = User
        fields = ('username', 'password')


class RecommendationForm(forms.ModelForm):
    class Meta:
        model = Recommendation
        fields = ['title', 'content']  # Include the fields you want to display in the form

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)  # Get the user from the view
        super().__init__(*args, **kwargs)

    def save(self, commit=True):
        recommendation = super().save(commit=False)
        if self.user:
            recommendation.created_by = self.user  # Automatically set the 'created_by' field to the current user
        if commit:
            recommendation.save()
        return recommendation

class FoodItemForm(forms.ModelForm):
    class Meta:
        model = FoodItem
        fields = ['name', 'price', 'description', 'image']


class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['bio', 'location', 'profile_picture', 'phone_number', 'birth_date']

    # Optionally, you can add custom validation or widgets here if needed.
    # For example, you can format the phone number field or birth date format.

    def clean_phone_number(self):
        phone_number = self.cleaned_data.get('phone_number')
        # Add validation if needed, like checking for phone number format
        return phone_number

    def clean_birth_date(self):
        birth_date = self.cleaned_data.get('birth_date')
        # Add validation for birth date if needed
        return birth_date