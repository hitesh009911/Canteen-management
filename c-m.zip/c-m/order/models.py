from django.db import models
from django.contrib.auth.models import User
from canteen.models import FoodItem
from django.db.models.signals import post_save
from django.dispatch import receiver


# Create your models here.
class Cart(models.Model):
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    food = models.ForeignKey(FoodItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

STATUS_CHOICES = (
    ("Pending", "Pending"),
    ("Accepted", "Accepted"),
    ("Cooking", "Cooking"),
    ("Packed", "Packed"),
    ("Completed", "Completed")
)

PAYMENT_CHOICES = (
    ("Cash", "Cash"),
    ("Online", "Online")
)

class Orders(models.Model):
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    total_amount = models.IntegerField()
    order_datetime = models.DateTimeField(auto_now_add=True)
    payment_mode = models.CharField(max_length=50, choices=PAYMENT_CHOICES)
    status = models.CharField(max_length=50, choices=STATUS_CHOICES, default="Pending")
    transaction_id = models.CharField(max_length=100)
    payment_gateway = models.CharField(max_length=50)

class OrderItems(models.Model):
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    order = models.ForeignKey("Orders", on_delete=models.CASCADE, related_name="items")
    name = models.CharField(max_length=50)
    price = models.IntegerField()
    quantity = models.PositiveIntegerField()
    item_total = models.IntegerField()

class Food(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name


ORDER_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('cooking', 'Cooking'),
        ('ready', 'Ready for Pickup'),
        ('completed', 'Completed')
    ]
class Order(models.Model):
    # Assign a default value (e.g., a specific Food item or create one)
    username = models.CharField(max_length=255, default='unknown')
    status = models.CharField(max_length=50, choices=ORDER_STATUS_CHOICES, default='pending')
    food_item = models.ForeignKey(Food, on_delete=models.CASCADE, default=1)  # Replace '1' with a valid ID
    quantity = models.IntegerField(default=1)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return f"Order {self.id} for {self.food_item.name}"


class FoodItem(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.CharField(max_length=5000,default="No description provided")  # Ensure this is added
    image = models.ImageField(upload_to='food_pic',default='food_pic/oip.jpeg')
    sold_out = models.BooleanField(default=False)  # Make sure this is correct

    def __str__(self):
        return self.name

class Purchase(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    food_item = models.ForeignKey(FoodItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    purchase_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username} - {self.food_item.name}'

    class Meta:
        ordering = ['-purchase_date']

class RecentPurchase(models.Model):
    order = models.OneToOneField(Order, on_delete=models.CASCADE)  # Link to Order table
    purchase_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Recent Purchase - {self.order.id}"

class Rating(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    rating = models.PositiveIntegerField()  # Scale of 1 to 5

    def __str__(self):
        return f"Rating {self.rating} for Order {self.order.id} by {self.user.username}"

class Feedback(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    feedback = models.TextField()
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)], null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback by {self.user.username} on {self.created_at}"

class Recommendation(models.Model):
    title = models.CharField(max_length=255)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name="recommendations")

    def __str__(self):
        return self.title

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True, null=True)
    profile_picture = models.ImageField(upload_to='profile_pictures/', blank=True, null=True)
    location = models.CharField(max_length=100, blank=True, null=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    birth_date = models.DateField(blank=True, null=True)
    social_links = models.JSONField(blank=True, null=True)  # Storing links as JSON (e.g., Facebook, Twitter)

    def __str__(self):
        return f"{self.user.username}'s Profile"

