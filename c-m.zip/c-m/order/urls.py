from django.urls import path, include
from . import views
from django.conf import settings
from django.conf.urls.static import static
from .views import toggle_sold_out

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('update-cart/<int:f_id>', views.update_cart, name='update-cart'),
    path('cart/', views.cart, name='cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('myorders/', views.my_orders, name='my-orders'),
    path('logout/', views.user_logout, name='logout'),
    path('api/menu/', views.get_food_menu, name='get_food_menu'),
    path('payment.html', views.payment, name='payment'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('toggle-sold-out/<int:item_id>/', views.toggle_sold_out, name='toggle_sold_out'),
    path('menu/', views.menu, name='menu'),
    path('recent-purchases/', views.recent_purchases, name='recent_purchases'),
    path('feedback/', views.feedback_list, name='feedback'),
    path('myorders/', views.my_orders, name='my_orders'),
    path('submit-feedback/', views.submit_feedback, name='submit_feedback'),
    path('manage_recommendations/', views.manage_recommendations, name='manage_recommendations'),
    path('recommendations/', views.recommendations_page, name='recommendations_page'),
    path('recommendation/delete/<int:recommendation_id>/', views.delete_recommendation, name='delete_recommendation'),
    path("manage-food-items/", views.manage_food_items, name="manage_food_items"),
    path('toggle-sold-out/<int:item_id>/', toggle_sold_out, name='toggle_sold_out'),
    path('add/', views.add_food_item, name='add-food-item'),
    path('manage-food-items/', views.manage_food_items, name='manage-food-items'),
    path('delete-food-item/<int:food_item_id>/', views.delete_food_item, name='delete-food-item'),
    path('update-food-item/<int:food_item_id>/', views.update_food_item, name='update-food-item'),
    path("orders/", views.manage_orders, name="manage_orders"),
    path('profile/', views.user_profile_view, name='user_profile_view'),
    path('profile/update/', views.update_profile, name='update_profile_view'),
    path('get_sales_data/<str:timeframe>/', views.get_sales_data, name='get_sales_data'),
]

# Append static URL patterns only in debug mode
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
